package com.finalproject.sulbao.cart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository {
}
