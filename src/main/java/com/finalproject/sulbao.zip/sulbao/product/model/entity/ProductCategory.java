package com.finalproject.sulbao.product.model.entity;

public enum ProductCategory {
    탁주, 과실주, 전통소, 약주, 기타
}
