package com.finalproject.sulbao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SulbaoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SulbaoApplication.class, args);
    }

}
