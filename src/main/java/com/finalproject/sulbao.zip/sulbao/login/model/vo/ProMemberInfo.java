//package com.finalproject.sulbao.login.model.vo;
//import jakarta.persistence.Column;
//import jakarta.persistence.Embeddable;
//import jakarta.persistence.EnumType;
//import jakarta.persistence.Enumerated;
//import lombok.*;
//
//import java.time.LocalDateTime;
//
//
//@Embeddable
//@Data
//@Setter(AccessLevel.PRIVATE)
//@NoArgsConstructor
//@AllArgsConstructor
//public class ProMemberInfo {
//
//    private int proNo;
//    private String proField;
//    private String businessNumber;
//    private String businessName;
//    private String businessLink;
//    @Column(nullable = false, columnDefinition = "'WAIT'")
//    @Enumerated(EnumType.STRING)
//    private String proStatus;
//    private LocalDateTime proRegistDate;
//}
