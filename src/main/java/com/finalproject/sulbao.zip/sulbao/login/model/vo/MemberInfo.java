package com.finalproject.sulbao.login.model.vo;

import com.finalproject.sulbao.login.model.entity.Login;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Embeddable
@Data
@Setter(AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
public class MemberInfo {

    private LocalDateTime verifyageDate;

    private String profileImg;

    private String profileName;

    private String profileText;

}
