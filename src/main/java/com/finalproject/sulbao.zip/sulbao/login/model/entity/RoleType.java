package com.finalproject.sulbao.login.model.entity;

public enum RoleType {
    ADMIN, MEMBER, SELLER
}
