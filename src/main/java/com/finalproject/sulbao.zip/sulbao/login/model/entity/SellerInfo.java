package com.finalproject.sulbao.login.model.entity;

import jakarta.persistence.*;
import lombok.*;

//@Entity
//@Table(name="seller_info")
//@NoArgsConstructor
//@AllArgsConstructor
//@Getter
//@Setter
//@ToString
public class SellerInfo {

    @Id
    private int sellerNo;

    @OneToOne(fetch = FetchType.LAZY)
    @MapsId
    @JoinColumn(name="user_no")
    private Login login;

    @Column(nullable = false)
    private String businessNumber;

    @Column(nullable = false)
    private String businessName;

    @Column(nullable = false, columnDefinition = "'WAIT'")
    @Enumerated(EnumType.STRING)
    private StatusType sellerStatus;
}
