package com.finalproject.sulbao.login.model.entity;

import com.finalproject.sulbao.login.model.vo.MemberInfo;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Table(name="tbl_login")
@SecondaryTables({
        @SecondaryTable(
            name="tbl_member_info",
            pkJoinColumns = @PrimaryKeyJoinColumn(name="member_no", referencedColumnName = "user_no")
        )
})
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Login {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="user_no")
    private Long userNo;

    @Column(unique = true, nullable = false)
    private String userId;

    @Column(nullable = false)
    private String userPw;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private RoleType userRole;

    @Column(nullable = false)
    @CreationTimestamp
    private LocalDateTime registDate;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String birth;

    @Column(nullable = false)
    private String phone;

    @Column(nullable = false)
    private String email;

//    @ElementCollection(fetch = FetchType.LAZY)
//    @CollectionTable(
//            name="member_info",
//            joinColumns = @JoinColumn(name="member_no", referencedColumnName = "user_no")
//    )
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="verifyageDate", column = @Column(name="verifyage_date", table = "tbl_member_info")),
            @AttributeOverride(name="profileImg", column = @Column(name="profile_img", table = "tbl_member_info")),
            @AttributeOverride(name="profileName", column = @Column(name="profile_name", table = "tbl_member_info")),
            @AttributeOverride(name="profileText", column = @Column(name="profile_text", table = "tbl_member_info"))
    })
    private MemberInfo memberInfo;
//
//    @Embedded
//    @AttributeOverrides({
//            @AttributeOverride(name = "")
//    })
//    private ProMemberInfo proMemberInfo;


}
