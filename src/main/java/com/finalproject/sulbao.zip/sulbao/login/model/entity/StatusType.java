package com.finalproject.sulbao.login.model.entity;

public enum StatusType {

    WAIT, APPROVE
}
